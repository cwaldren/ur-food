var dininghours = 
  [
    {name: 'Danforth', days: {
		
    		'Monday-Thursday': {times:
			[ 
	    		{what: 'breakfast', open: '11am', close: '1:30pm'},
	    		{what: 'dinner'   , open: '5pm' , close: '9pm'},
	    		{what: 'lunch'    , open: '11am', close: '1:30pm'}
	    	]},
	    	'Friday': {times: 
			[ 
	    		{what: 'select stations', open: '1:30pm', close: '5pm'},
	    		{what: 'dinner'         , open: '5pm'   , close: '9pm'}
	    	]},		
	    	'Saturday': {times:
			[
	    		{what: 'continental breakfast', open: '8am'    , close: '10:30am'},
	    		{what: 'brunch'               , open: '10:30am', close: '2pm'},
	    		{what: 'select stations'      , open: '2pm'    , close: '5pm'},
	    		{what: 'dinner'               , open: '5pm'    , close: '9pm'},
	    	]},	
	    	'Sunday': {times: 
			[
	    		{what: 'continental breakfast', open: '8am'    , close: '10:30am'},
	    		{what: 'brunch'               , open: '10:30am', close: '2pm'},
	    		{what: 'select stations'      , open: '2pm'    , close: '5pm'},
	    		{what: 'dinner'               , open: '5pm'    , close: '9pm'},
	    	]}
    
	  	
    	
	}},

	
    {name: 'Hillside POD', days: {
		
    		'Monday-Thursday' : {times:
			[ 
	    		{what: 'groceries', open: '7:30am', close: '3am'}
	    	]},
	    	'Friday': {times: 
			[ 
				{what: 'groceries', open: '7:30am', close: '3am'}
	    	]},		
	    	'Saturday': {times:
			[
	    		{what: 'groceries', open: '12pm', close: '3am'}
	    	]},	
	    	'Sunday': {times:
			[
	    		{what: 'groceries', open: '12pm', close: '3am'}
	    	]}	
    
	    	
    	
	}}


];
